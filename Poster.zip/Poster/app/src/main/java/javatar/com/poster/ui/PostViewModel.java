package javatar.com.poster.ui;

import android.annotation.SuppressLint;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import javatar.com.poster.data.PostClient;
import javatar.com.poster.pojo.Post;

public class PostViewModel extends ViewModel {

    MutableLiveData<List<Post>> postsMutableLiveData = new MutableLiveData<>();

    private static final String TAG = "PostViewModel";
    @SuppressLint("CheckResult")
    public void getPosts(){

        Single<List<Post>> single = PostClient.getPostInstance().getPosts()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());

        single.subscribe(
          o-> postsMutableLiveData.setValue(o),
          e-> Log.d(TAG, "getPosts: "+e)
        );

//        PostClient.getPostInstance().getPosts().enqueue(new Callback<List<Post>>() {
//            @Override
//            public void onResponse(@NonNull Call<List<Post>> call,@NonNull Response<List<Post>> response) {
//                postsMutableLiveData.setValue(response.body());
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<List<Post>> call,@NonNull Throwable t) {
//                Log.d(TAG,"ahmed" , t);
//            }
//        });
    }
}
